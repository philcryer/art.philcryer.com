+++
date = "2017-05-15T22:25:16-07:00"
title = "Toma Nistor"
image = "toma-nistor.png"
alt = "Toma Nistor"
color = "#212121"
link1 = "https://tomanistor.com"
link2 = "https://github.com/tomanistor/tomanistor.com"

+++
