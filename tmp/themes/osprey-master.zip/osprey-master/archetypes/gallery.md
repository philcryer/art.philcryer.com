+++
title = "{{ replace .TranslationBaseName "-" " " | title }}"
date = {{ .Date }}
image = ""
alt = ""
color = ""
link1 = ""
link2 = ""
draft = true
+++
